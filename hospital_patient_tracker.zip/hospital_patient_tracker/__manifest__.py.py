{
    'name': 'Hospital Patient Tracker',
    'version': '1.0',
    'category': 'Healthcare',
    'summary': 'Manage hospital patients',
    'description': 'A module to manage hospital patients, including tracking patient details and records.',
    'author': 'Your Name',
    'website': 'https://www.example.com',
    'depends': ['base'],
    'data': [
        'views/patient_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
