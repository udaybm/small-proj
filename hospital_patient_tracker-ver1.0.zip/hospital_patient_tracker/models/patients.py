from odoo import models, fields, api
class Patient(models.Model):
    _name = 'hospital.patient'
    _description = 'Hospital Patient'

    reference = fields.Char(string='Reference', required=True, copy=False, readonly=True, default=lambda self: 'New')
    name = fields.Char(string='Name', required=True)
    age = fields.Integer(string='Age', required=True)
    gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ], required=True, default='male', string='Gender')

    @api.model
    def create(self, vals):
        if vals.get('reference', 'New') == 'New':
            vals['reference'] = self.env['ir.sequence'].next_by_code('hospital.patient') or 'New'
        result = super(Patient, self).create(vals)
        return result