{
    'name': 'Hospital Patient Tracker',
    'version': '1.0',
    'summary': 'Module for managing hospital patients',
    'description': """
        Hospital Patient Tracker
    """,
    'category': 'Healthcare',
    'author': 'Uday M',
    'website': 'http://yourwebsite.com',
    'depends': ['base'],
    'data': [
    'security/ir.model.access.csv',
	'views/patients_view.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
